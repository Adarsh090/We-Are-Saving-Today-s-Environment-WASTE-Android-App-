package com.choudhary.waste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class App_Data_Next extends AppCompatActivity implements View.OnClickListener {
    private Button uploadImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_data_next);
        uploadImage = (Button) findViewById(R.id.imageupload);
        uploadImage.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imageupload:
                startActivity(new Intent(this,ImageUpload.class));
                break;
        }
    }
}