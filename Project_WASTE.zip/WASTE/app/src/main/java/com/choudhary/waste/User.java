package com.choudhary.waste;

public class User {
    public String fullname,age,email;

    public User(){

    }
    public User(String fullname,String age,String email){
        this.fullname = fullname;
        this.age = age;
        this.email = email;
    }
}
