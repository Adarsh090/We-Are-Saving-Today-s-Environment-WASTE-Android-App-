package com.choudhary.waste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AppData extends AppCompatActivity implements View.OnClickListener {
    private Button nextbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_data);
        nextbutton = (Button) findViewById(R.id.next);
        nextbutton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.next:
                startActivity(new Intent(this,App_Data_Next.class));
                break;
        }
    }
}